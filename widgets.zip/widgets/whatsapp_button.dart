import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';
// Solo para Web:
import 'dart:html' as html;

/// Un FloatingActionButton con animación vertical y que abre WhatsApp
class WhatsAppButton extends StatefulWidget {
  const WhatsAppButton({super.key});

  @override
  State<WhatsAppButton> createState() => _WhatsAppButtonState();
}

class _WhatsAppButtonState extends State<WhatsAppButton>
    with SingleTickerProviderStateMixin {
  static const _phone = '573144613936';
  static const _text = '¡Hola! Me interesa un perfume.';

  late final AnimationController _ctl = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat(reverse: true);

  late final Animation<double> _animY = Tween(begin: -8.0, end: 8.0)
      .chain(CurveTween(curve: Curves.easeInOut))
      .animate(_ctl);

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _openWhatsapp() async {
    // Construye un link universal
    final link = WhatsAppUnilink(
      phoneNumber: '+57 $_phone',
      text: _text,
    );

    final nativeUri = link.asUri();
    final webUriString =
        'https://wa.me/$_phone?text=${Uri.encodeComponent(_text)}';

    if (kIsWeb) {
      // En web abrimos en nueva pestaña usando la URL wa.me
      html.window.open(webUriString, '_blank');
      return;
    }

    // En nativo intentamos esquema whatsapp://
    if (await canLaunch(nativeUri.toString())) {
      html.window.location.assign(nativeUri.toString());
    } else {
      // Fallback a wa.me (requiere url_launcher si se necesita abrir HTML)
      html.window.location.assign(webUriString);
    }
  }

  bool canLaunch(String uri) {
    // En Web siempre lanzamos wa.me, en nativo delegamos a url_launcher si se importa
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animY,
      builder: (_, child) => Transform.translate(
        offset: Offset(0, _animY.value),
        child: child,
      ),
      child: FloatingActionButton(
        onPressed: _openWhatsapp,
        backgroundColor: const Color(0xFF25D366),
        tooltip: 'Chatear por WhatsApp',
        child: ClipOval(
          child: Image.asset(
            'assets/whatsappiconchat.png',
            width: 40,
            height: 40,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}